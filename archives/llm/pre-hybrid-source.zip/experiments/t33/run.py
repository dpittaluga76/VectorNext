"""Bounded three-model comparison. Fresh runs only; measured attempts never retry."""
import argparse
import base64
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import subprocess
import threading
import time
import zipfile
from deployment.client import Client
from model_worker.generator_profile import load, command, verify as verify_model

HERE=Path('experiments/t33')
ARMS=('12b','qwen35-9b-q4km','granite42-8b-q4km')
IMAGES=('vectornext-app:t28-12b','vectornext-app-processor:t33','vectornext-app-llm:t33')


def write(path,value):
    path.write_text(json.dumps(value,indent=2)+'\n',encoding='utf-8',newline='\n')


def digest(path): return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def validate():
    for path,expected in json.loads((HERE/'input-freeze.json').read_bytes()).items():
        if digest(path)!=expected:raise ValueError('frozen input changed: '+path)
    explicit=json.loads(Path('experiments/t32/requests.json').read_bytes())
    browser=json.loads((HERE/'browser-requests.json').read_bytes())
    if len(explicit)!=6 or len(browser)!=2:raise ValueError('24-request bound')
    options={'candidates':30,'rerank_limit':20,'primary_limit':5,'rerank':True,'evidence_strategy':'ranked'}
    cases={key:('/v1/ask',{'request':value,'options':options}) for key,value in explicit.items()}
    cases.update({key:('/v1/ui/ask',dict(value,options=options)) for key,value in browser.items()})
    return cases


class Run:
    def __init__(self,name):
        if not name or any(c not in 'abcdefghijklmnopqrstuvwxyz0123456789-' for c in name):
            raise ValueError('simple fresh run name required')
        self.project='vectornext-t33-'+name
        self.root=Path('data/t33')/name
        self.root.mkdir(exist_ok=False)
        self.env=os.environ.copy()
        self.client=Client('http://127.0.0.1:8102')
        self.normal=Client('http://127.0.0.1:8088')

    def shell(self,*args):
        result=subprocess.run(args,env=self.env,capture_output=True,text=True,encoding='utf-8')
        with (self.root/'commands.log').open('a',encoding='utf-8') as stream:
            stream.write(json.dumps(args)+'\n'+result.stdout+result.stderr+'\n')
        if result.returncode:raise RuntimeError(result.stderr[-2000:])
        return result.stdout.strip()

    def compose(self,*args):
        return self.shell('docker','compose','-f','compose.t33.yaml','-p',self.project,*args)

    def call(self,path,body=None,client=None):
        code,result=(client or self.client).request_once(path,body)
        if code!=200:raise RuntimeError((path,code,result))
        return result

    def normal_state(self):
        return {k:self.call(v,client=self.normal) for k,v in (
            ('documents','/v1/documents'),('library','/v1/ui/library'),('jobs','/v1/jobs'),('ready','/readyz'))}

    def snapshot(self):
        return {d['document_id']:self.call('/v1/document',{'document_id':d['document_id']})['document']
                for d in self.call('/v1/documents')['documents']}

    def wait_ready(self,normal=False):
        client=self.normal if normal else self.client
        deadline=time.monotonic()+240
        last=None
        while time.monotonic()<deadline:
            try:
                code,last=client.request_once('/readyz',timeout=10)
                if code==200:return last
            except (OSError,ValueError) as error:last=str(error)
            if not normal:
                state=self.shell('docker','inspect',self.project+'-llm-1','--format','{{.State.Status}}')
                if state=='exited':raise RuntimeError('generator exited; inspect retained log')
            time.sleep(1)
        raise RuntimeError(('readiness timeout',last))

    def select(self,profile,cache,folder):
        self.compose('stop')
        self.env.update(T33_PROFILE=profile,T33_CACHE=cache)
        started=time.monotonic()
        self.compose('up','-d','--no-build','--pull','never','--force-recreate')
        ready=self.wait_ready()
        write(folder/'startup.json',{'seconds':time.monotonic()-started,'ready':ready})
        (folder/'compose.json').write_text(self.compose('config','--format','json'),encoding='utf-8')
        # Capture the actual backend invocation, not only desired Compose settings.
        script="import pathlib,json; print(json.dumps([p.read_bytes().decode().split(chr(0)) for p in pathlib.Path('/proc').glob('[0-9]*/cmdline') if p.read_bytes().startswith(b'/opt/llama/llama-server')]))"
        launched=json.loads(self.compose('exec','-T','llm','python','-c',script))
        expected=command(load(profile));expected[expected.index('--host')+1]='127.0.0.1';expected[expected.index('--port')+1]='8081'
        if launched!=[['/opt/llama/llama-server',*expected,'']]:raise ValueError('actual backend command mismatch')
        write(folder/'backend-command.json',launched)

    def ingest(self):
        folder=self.root/'corpus';folder.mkdir()
        self.select('12b','ingest',folder)
        if self.call('/v1/documents')['documents'] or self.call('/v1/jobs')['jobs']:
            raise ValueError('fresh storage required')
        rows=[]
        for source in json.loads(Path('experiments/t32/sources.json').read_bytes())['sources']:
            path=Path('experiments/t32')/source['file'];identifier=source['id'];started=time.monotonic()
            try:
                code,value=self.client.request_once('/v1/ingest',{'job_id':'t33-'+identifier,
                    'document_id':identifier,'policy':'structural','record_pointer':'',
                    'media_type':{'.txt':'Txt','.pdf':'Pdf','.json':'Json'}[path.suffix],
                    'source_base64':base64.b64encode(path.read_bytes()).decode()})
                (folder/(identifier+'.admission.json')).write_bytes(self.client.raw)
                if code==202:code,value=self.client.wait('t33-'+identifier)
                row={'document':identifier,'committed':code==200 and value.get('stage')=='Committed','http_status':code,'job':value}
            except Exception as error:row={'document':identifier,'committed':False,'error':str(error)}
            row['seconds']=time.monotonic()-started;rows.append(row);write(folder/'ingestion.json',rows)
            print('ingest',identifier,row['committed'],round(row['seconds'],2),flush=True)
        docs=self.snapshot();write(folder/'documents.json',docs)
        return docs

    def sample(self,stop,folder):
        with (folder/'resources.jsonl').open('x',encoding='utf-8') as stream:
            while not stop.is_set():
                row={'utc':datetime.now(timezone.utc).isoformat()}
                for key,args in [('gpu',['nvidia-smi','--query-gpu=name,memory.total,memory.used,utilization.gpu','--format=csv,noheader,nounits']),
                                 ('containers',['docker','stats','--no-stream','--format','{{json .}}',*[self.project+'-'+s+'-1' for s in ('api','processor','llm')]])]:
                    result=subprocess.run(args,capture_output=True,text=True,encoding='utf-8')
                    row[key]={'exit':result.returncode,'output':result.stdout,'error':result.stderr}
                stream.write(json.dumps(row)+'\n');stream.flush();stop.wait(2)

    def freeze_execution(self):
        paths={p for directory in ('model_worker','deployment','experiments/t33','experiments/t32','processor')
               for p in Path(directory).rglob('*') if p.is_file() and '__pycache__' not in p.parts}
        paths|={Path(p) for p in ('compose.t33.yaml','docker/app-processor.Dockerfile','docker/app-llm.Dockerfile',
            'experiments/t02/encoders.py','experiments/t02/fetch_models.py','experiments/t02/requirements.txt',
            'experiments/t02/models.lock.json','experiments/t02/models.26b.lock.json','experiments/t27/models.12b.lock.json',
            'experiments/t31/models.bge.lock.json','evals/evidence/score.py','docs/t33-protocol.md')}
        self.freeze={'created':datetime.now(timezone.utc).isoformat(),'requests':24,'arms':ARMS,
            'commit':self.shell('git','rev-parse','HEAD'),'project':self.project,
            'files':{p.as_posix():digest(p) for p in sorted(paths)},
            'images':{tag:self.shell('docker','image','inspect',tag,'--format','{{.Id}}') for tag in IMAGES},
            'profiles':{name:{'profile':load(name),'command':command(load(name))} for name in ARMS}}
        write(self.root/'execution-freeze.json',self.freeze)
        with zipfile.ZipFile(self.root/'source.zip','x',zipfile.ZIP_DEFLATED) as archive:
            for path in paths:archive.write(path,path.as_posix())

    def verify(self):
        validate()
        if any(digest(p)!=h for p,h in self.freeze['files'].items()):raise ValueError('execution inputs changed')
        for tag,identity in self.freeze['images'].items():
            if self.shell('docker','image','inspect',tag,'--format','{{.Id}}')!=identity:raise ValueError('image changed')

    def execute(self):
        cases=validate()
        existing=self.shell('docker','volume','ls','--format','{{.Name}}').splitlines()
        if any(v.startswith(self.project+'_') for v in existing):raise ValueError('existing project volumes')
        for profile in ARMS:verify_model(load(profile),Path('models'))
        before=self.normal_state();write(self.root/'normal-before.json',before)
        if any(j['stage']!='Committed' for j in before['jobs']['jobs']):raise ValueError('normal ingestion is unfinished')
        original=json.loads(self.shell('docker','inspect','vectornext-llm-1'))[0]
        write(self.root/'normal-generator.json',original)
        if not original['State']['Running']:raise ValueError('expected running normal generator')
        self.freeze_execution()
        try:
            self.shell('docker','stop','vectornext-llm-1')
            docs=self.ingest()
            for profile in ARMS:
                self.verify();folder=self.root/profile;folder.mkdir()
                stop=threading.Event();sampler=threading.Thread(target=self.sample,args=(stop,folder));sampler.start()
                preflight_error=None
                try:
                    try:
                        self.select(profile,'query/'+profile,folder)
                        result=self.compose('exec','-T','processor','python','-c',(HERE/'preflight.py').read_text())
                        (folder/'preflight.json').write_text(result,encoding='utf-8')
                        started=time.monotonic();self.compose('restart','llm');ready=self.wait_ready()
                        write(folder/'restart.json',{'seconds':time.monotonic()-started,'ready':ready})
                        result=self.compose('exec','-T','processor','python','-c',Path('experiments/t32/warmup.py').read_text())
                        (folder/'warmup.json').write_text(result,encoding='utf-8')
                        if self.snapshot()!=docs:raise ValueError('committed corpus changed')
                    except Exception as error:
                        preflight_error=str(error);write(folder/'preflight-failure.json',{'error':preflight_error})
                        print(profile,'PREFLIGHT FAILED',preflight_error,flush=True)
                    for identifier,(path,body) in cases.items():
                        with (folder/(identifier+'.attempt.json')).open('x',encoding='utf-8') as stream:
                            json.dump({'utc':datetime.now(timezone.utc).isoformat(),'path':path,'request':body,
                                       'blocked_by_preflight':preflight_error},stream)
                        started=time.monotonic();error=preflight_error;code=0;raw=b''
                        if not preflight_error:
                            try:code,_=self.client.request_once(path,body);raw=self.client.raw
                            except Exception as failure:error=str(failure)
                        (folder/(identifier+'.response.json')).write_bytes(raw)
                        write(folder/(identifier+'.row.json'),{'case':identifier,'http_status':code,
                            'seconds':None if preflight_error else time.monotonic()-started,'error':error,
                            'response_sha256':hashlib.sha256(raw).hexdigest()})
                        print(profile,identifier,code,round(time.monotonic()-started,2),flush=True)
                    if not preflight_error and self.snapshot()!=docs:raise ValueError('requests mutated corpus')
                finally:
                    stop.set();sampler.join()
                    (folder/'services.log').write_text(self.compose('logs','--no-color'),encoding='utf-8')
                    self.compose('stop')
            self.verify()
        finally:
            try:
                (self.root/'final-services.log').write_text(self.compose('logs','--no-color'),encoding='utf-8')
                # Release the fixed isolated subnets for a future fresh run.
                # No --volumes: durable corpus and caches remain retained.
                self.compose('down')
            finally:
                self.shell('docker','start','vectornext-llm-1');self.wait_ready(normal=True)
                after=self.normal_state();write(self.root/'normal-after.json',after)
                if any(before[k]!=after[k] for k in ('documents','library','jobs')):raise ValueError('normal data changed')
                current=json.loads(self.shell('docker','inspect','vectornext-llm-1'))[0]
                if current['Id']!=original['Id'] or current['Config']!=original['Config']:raise ValueError('normal profile changed')


if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('--run',required=True)
    Run(parser.parse_args().run).execute()
