import copy
import unittest
from model_worker import generator_profile as profiles
from model_worker.cache import digest


class CandidateProfiles(unittest.TestCase):
    def test_candidates_bind_artifact_template_and_alias(self):
        identities=[]
        for name in ('12b','qwen35-9b-q4km','granite42-8b-q4km'):
            p=profiles.load(name);args=profiles.command(p)
            self.assertEqual(profiles.validate_command(p,args),args)
            identities.append(digest({'artifact':p['artifact'],'runtime':profiles.runtime_identity(p)}))
            if name!='12b':
                self.assertEqual(args[args.index('--chat-template-kwargs')+1],'{"enable_thinking":false}')
                self.assertIn(';chat-template-kwargs=',profiles.runtime_identity(p))
                with self.assertRaises(ValueError):
                    profiles.validate_command(p,args+['--reasoning','on'])
            else:
                self.assertNotIn('--chat-template-kwargs',args)
                self.assertNotIn(';chat-template-kwargs=',profiles.runtime_identity(p))
        self.assertEqual(len(set(identities)),3)

    def test_template_options_fail_closed(self):
        for options in ({}, {'enable_thinking':True}, {'enable_thinking':0}, [],
                        {'enable_thinking':False,'other':False}):
            p=copy.deepcopy(profiles.load('12b'));p['chat_template_kwargs']=options
            with self.assertRaises(ValueError):profiles.command(p)
            with self.assertRaises(ValueError):profiles.runtime_identity(p)

    def test_candidate_scheduler_rejects_other_model(self):
        import json
        from model_worker.scheduler import validate, Rejected
        q=profiles.load('qwen35-9b-q4km')['alias'];g=profiles.load('granite42-8b-q4km')['alias']
        body=json.dumps({'model':q,'max_tokens':768,'temperature':0})
        validate('/v1/chat/completions',body,'interactive',q)
        with self.assertRaises(Rejected):validate('/v1/chat/completions',body,'interactive',g)


if __name__=='__main__':unittest.main()
