import json
import unittest
from model_worker import generator_profile as profiles
from model_worker.cache import digest
from model_worker.scheduler import validate, Rejected
from .run import ARMS, SELECTED, validate as validate_inputs


class CandidateProfiles(unittest.TestCase):
    def test_artifacts_and_commands_are_distinct_without_changing_defaults(self):
        identities = []
        for name in ARMS:
            profile = profiles.load(name)
            args = profiles.command(profile)
            self.assertEqual(profiles.validate_command(profile, args), args)
            self.assertEqual(profile['cpu_moe'], 0)
            self.assertNotIn('--chat-template-kwargs', args)
            self.assertNotIn('--cache-type-k', args)
            self.assertEqual(args[args.index('--ctx-size') + 1], '4096')
            identities.append(digest({'artifact': profile['artifact'],
                                      'runtime': profiles.runtime_identity(profile)}))
            with self.assertRaises(ValueError):
                profiles.validate_command(profile, args + ['--ctx-size', '2048'])
        self.assertEqual(len(set(identities)), 4)
        self.assertEqual(json.loads(profiles.CATALOG.read_bytes())['default'], '12b')

    def test_scheduler_accepts_only_selected_alias(self):
        aliases = [profiles.load(name)['alias'] for name in ARMS]
        for alias in aliases:
            body = json.dumps({'model': alias, 'max_tokens': 768, 'temperature': 0})
            validate('/v1/chat/completions', body, 'interactive', alias)
            for other in aliases:
                if other != alias:
                    with self.assertRaises(Rejected):
                        validate('/v1/chat/completions', body, 'interactive', other)

    def test_frozen_selection_is_twenty_four_requests(self):
        cases = validate_inputs()
        self.assertEqual(len(cases) * len(ARMS), 24)
        self.assertEqual(tuple(cases)[:4], SELECTED)
        self.assertEqual(sum(path == '/v1/ui/ask' for path, _ in cases.values()), 2)


if __name__ == '__main__':
    unittest.main()
