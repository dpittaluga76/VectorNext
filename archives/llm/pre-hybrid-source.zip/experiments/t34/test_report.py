import json
import unittest
from .report import case_score
from .score import case_score as frozen_score


class ReportingTests(unittest.TestCase):
    def test_rejected_metadata_never_becomes_evidence_or_success(self):
        label={'status':'supported','values':{'n':12},'facts':[]}
        raw=json.dumps({'error':{'message':'quote mismatch','diagnostics':{
            'evidence':[{'id':'E1','key':{'document_id':'d'}}],
            'unvalidated_draft':{'status':'supported','fields':{'n':{'value':12}}}}}}).encode()
        result=case_score(400,raw,label,{})
        self.assertFalse(result['correct'])
        self.assertEqual(result['error'],'quote mismatch')
        self.assertEqual(result['values_text'],{})
        self.assertTrue(all(v['complete'] is None for v in result['coverage'].values()))

    def test_blocked_browser_and_false_negative_http_errors_fail(self):
        for browser,label in [(False,{'status':'insufficient_evidence','values':{},'facts':[]}),
                              (True,{'status':'supported','value':12,'kind':'integer','facts':[]})]:
            result=case_score(0,b'',label,{},browser)
            self.assertFalse(result['correct'])
            self.assertIsNone(result['citations']['complete'])

    def test_success_scoring_is_identical(self):
        label={'status':'supported','values':{'n':9007199254740993},'facts':[]}
        raw=json.dumps({'answer':{'status':'supported','fields':{'n':{'value':9007199254740993}}},
                        'validation':{'mechanical_support':'passed'}}).encode()
        self.assertEqual(case_score(200,raw,label,{}),frozen_score(200,raw,label,{}))


if __name__=='__main__':unittest.main()
