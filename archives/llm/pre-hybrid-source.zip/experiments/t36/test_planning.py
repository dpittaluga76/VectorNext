import copy
import json
import unittest
from types import SimpleNamespace
from unittest.mock import patch
from model_worker import planning, generator_profile as profiles
from model_worker.cache import digest
from .run import validate
from .score import match_fields


class PlanningVariantTests(unittest.TestCase):
    def test_profile_only_changes_alias_and_versioned_planning_identity(self):
        old = profiles.load('nuextract3-q4km'); new = profiles.load('nuextract3-requested-facts-v1')
        ignored = {'name','alias','planning_variant'}
        self.assertEqual({k:v for k,v in old.items() if k not in ignored}, {k:v for k,v in new.items() if k not in ignored})
        cmd = profiles.command(new); cmd[cmd.index('--alias')+1] = old['alias']
        self.assertEqual(cmd, profiles.command(old))
        self.assertEqual(profiles.runtime_identity(new), profiles.runtime_identity(old)+';planning-variant=requested-facts-v1')
        self.assertIsNone(profiles.planning_variant(old))
        self.assertEqual(profiles.load()['name'], '12b')

    def test_invalid_variant_fails_closed(self):
        for profile in ({'planning_variant':'unknown'}, {'planning_variant':True},
                        {'planning_variant':'requested-facts-v1'},
                        {**profiles.load('12b'),'planning_variant':'requested-facts-v1'}):
            with self.assertRaises(ValueError): profiles.planning_variant(profile)

    def test_one_call_unchanged_schema_original_inputs_and_versioned_audit(self):
        data = {'question':'What is its height?', 'history':[{'role':'user','text':'Which tower?'}]}
        for name in ('12b','nuextract3-q4km','nuextract3-requested-facts-v1'):
            worker = SimpleNamespace(generation_profile=profiles.load(name))
            with patch.object(planning,'generate',return_value=({'status':'needs_clarification','fields':[]},{})) as generate:
                reply = planning.handle(worker, data)
            self.assertEqual(generate.call_count, 1)
            _, messages, schema, prompt = generate.call_args.args
            changed = name.endswith('requested-facts-v1')
            self.assertEqual(prompt, planning.PROMPT + (planning.REQUESTED_FACTS if changed else ''))
            self.assertEqual(messages[0]['content'], prompt)
            self.assertEqual(json.loads(messages[1]['content']), {'ORIGINAL QUESTION':data['question'],'CONVERSATION':data['history']})
            self.assertIs(schema, planning.SCHEMA)
            self.assertEqual(reply['audit']['planning_version'], 'field-planning-v3'+(';requested-facts-v1' if changed else ''))
            self.assertEqual(reply['audit']['input_sha256'], digest(data))
            self.assertFalse(reply['audit']['evidence_available'])

    def test_no_silent_pruning_or_forced_single_field(self):
        fields = [{'name':'count','kind':'integer','nullable':False,'description':'Requested berth count'},
                  {'name':'year','kind':'integer','nullable':False,'description':'Unrequested year'}]
        plan = {'status':'ready','fields':fields}
        worker = SimpleNamespace(generation_profile=profiles.load('nuextract3-requested-facts-v1'))
        with patch.object(planning,'generate',return_value=(copy.deepcopy(plan),{})) as generate:
            reply = planning.handle(worker, {'question':'How many berths in 2034?', 'history':[]})
        self.assertEqual(reply['plan'], plan)
        self.assertEqual(generate.call_count, 1)
        self.assertIsNone(match_fields(plan,[{'kind':'integer','meaning':'berth'}]))

    def test_frozen_fresh_cases_and_defaults(self):
        cases = validate()
        self.assertEqual(len(cases), 8)
        self.assertTrue(all(path == '/v1/ui/ask' and 'fields' not in body for path,body in cases.values()))
        self.assertEqual(cases['followup_draft'][1]['history'][1]['text'],'berth_count: 18 (integer)')


if __name__ == '__main__': unittest.main()
