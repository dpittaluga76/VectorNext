"""Post-run review sidecar. Never replaces the frozen score or labels.

See docs/reports/t36-source-review.md for the two narrowly checked exceptions.
No inference or changed runtime inputs.
"""
import argparse
import copy
import json
from pathlib import Path
from evals.evidence.score import distribution
from .report import summarize, serializable
from .run import HERE, digest
from .score import exact_load, normalize, score

PDF_SHA = '4679ddc960917334baedb22a37d3ac6da5ca491a89f18d051605b1de7a4fc5f0'
AGGREGATE_ERROR = 'invalid record: aggregate question requires an unsupported corpus aggregation operation'


def review_case(identifier, code, raw, label, documents):
    if identifier == 'aggregate_sum':
        body = exact_load(raw) if raw else {}
        return (label['plan']=='unsupported' and code==400
                and body.get('error')=={'code':'invalid_request','message':AGGREGATE_ERROR})
    if identifier != 'pdf_pressure' or code != 200: return False
    try:
        view = exact_load(raw); report = exact_load(view['raw_report'])
        docs = copy.deepcopy(documents); doc = docs['vela']
        if doc['original']['sha256'] != PDF_SHA: return False
        heading = doc['blocks'][0]
        if heading['kind'] != 'Heading' or heading['text'] != 'Vela-X service certificate': return False
        if not heading['sources'] or any(s['revision']!=doc['revision'] or s['locator']['Pdf']['page']!=1 for s in heading['sources']): return False
        cited = {p['evidence_id'] for p in report['answer']['fields'].values()}
        for e in report['evidence']:
            if e['id'] not in cited: continue
            if e['key']['document_id']!='vela' or e['key']['revision']!=doc['revision']: return False
            chunk = next(c for c in doc['chunks'] if c['id']==e['key']['chunk_id'])
            assembled = heading['text']+'\n\n'+chunk['evidence']
            if normalize(assembled)!=normalize(e['text']) or e['spans']!=chunk['spans']: return False
            # Only the provenance comparison receives the verified heading-expanded
            # passage; every frozen plan/value/type/projection/fact check still runs.
            chunk['evidence'] = assembled
        return score(code,raw,label,docs)['correct']
    except (ValueError,KeyError,TypeError,StopIteration):
        return False


def reviewed_summary(root):
    root = Path(root); result = summarize(root)
    docs = exact_load((root/'corpus/documents.json').read_bytes())
    gold = exact_load((HERE/'gold.json').read_bytes())
    for name, arm in result['arms'].items():
        for row in arm['cases']:
            raw = (root/name/(row['case']+'.response.json')).read_bytes()
            corrected = review_case(row['case'],row['http_status'],raw,gold[row['case']],docs)
            row['reviewed_correct'] = row['score']['correct'] or corrected
            row['review_exception'] = row['case'] if corrected and not row['score']['correct'] else None
            # The API aggregate guard runs before the planner: do not credit the model.
            row['planner_observed'] = row['case'] != 'aggregate_sum'
        arm['reviewed_correct'] = sum(r['reviewed_correct'] for r in arm['cases'])
        arm['planner_correct_excluding_api_aggregate'] = sum(r['score']['planning_correct'] for r in arm['cases'] if r['planner_observed'])
        arm['planner_denominator'] = 7
        arm['reviewed_comparisons'] = {}
    for arm in result['arms'].values():
        for control in ('12b','nuextract3-q4km'):
            pairs = list(zip(result['arms'][control]['cases'], arm['cases']))
            common = [(a,b) for a,b in pairs if a['reviewed_correct'] and b['reviewed_correct']]
            positive = [(a,b) for a,b in common if gold[a['case']].get('outcome')=='supported']
            arm['reviewed_comparisons'][control] = {
                'gained':[b['case'] for a,b in pairs if b['reviewed_correct'] and not a['reviewed_correct']],
                'lost':[b['case'] for a,b in pairs if a['reviewed_correct'] and not b['reviewed_correct']],
                'common_correct_seconds':{'control':distribution([a['seconds'] for a,b in common]),
                                          'candidate':distribution([b['seconds'] for a,b in common])},
                'common_supported_seconds':{'control':distribution([a['seconds'] for a,b in positive]),
                                            'candidate':distribution([b['seconds'] for a,b in positive])}}
    result['review_reference'] = 'docs/reports/t36-source-review.md'
    result['reviewer_sha256'] = digest(Path(__file__))
    return result


if __name__ == '__main__':
    p=argparse.ArgumentParser();p.add_argument('--run',required=True);p.add_argument('--output',required=True,type=Path)
    a=p.parse_args()
    a.output.write_text(json.dumps(reviewed_summary(Path('data/t36')/a.run),indent=2,default=serializable)+'\n',encoding='utf-8',newline='\n')
