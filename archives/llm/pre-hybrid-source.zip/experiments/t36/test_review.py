import copy
import json
import unittest
from .review import review_case, PDF_SHA, AGGREGATE_ERROR
from . import test_score


class ReviewTests(unittest.TestCase):
    def fixture(self):
        base=test_score.ScoreTests();base.setUp()
        doc=base.docs.pop('doc');base.docs['vela']=doc
        doc.update(original={'sha256':PDF_SHA},blocks=[{'kind':'Heading','text':'Vela-X service certificate',
                    'sources':[{'revision':'r','locator':{'Pdf':{'page':1}}}]}])
        doc['chunks'][0]['spans']=[{'block_id':'b1','bytes':{'start':0,'end':22}}]
        e=base.report['evidence'][0];e['key']['document_id']='vela'
        e['text']='Vela-X service certificate\n\n'+e['text'];e['spans']=copy.deepcopy(doc['chunks'][0]['spans'])
        base.gold['fields'][0]['facts'][0]['document']='vela'
        return base

    def check(self,base):
        raw=json.dumps(dict(base.view,raw_report=json.dumps(base.report))).encode()
        return review_case('pdf_pressure',200,raw,base.gold,base.docs)

    def test_heading_review_keeps_every_other_contract(self):
        self.assertTrue(self.check(self.fixture()))
        for mutation in ('source_hash','text','revision','spans','value','extra_field','projection'):
            b=self.fixture();e=b.report['evidence'][0]
            if mutation=='source_hash':b.docs['vela']['original']['sha256']='other'
            if mutation=='text':e['text']='Invented heading\n'+e['text']
            if mutation=='revision':e['key']['revision']='old'
            if mutation=='spans':e['spans']=[]
            if mutation=='value':b.report['answer']['fields']['berths']['value']=19
            if mutation=='extra_field':b.report['planning']['plan']['fields'].append(dict(b.spec,name='year'))
            if mutation=='projection':b.view['fields'][0]['value_text']='19'
            self.assertFalse(self.check(b),mutation)

    def test_only_the_exact_upstream_aggregate_guard_is_reviewed(self):
        label={'plan':'unsupported'}
        raw=json.dumps({'error':{'code':'invalid_request','message':AGGREGATE_ERROR}}).encode()
        self.assertTrue(review_case('aggregate_sum',400,raw,label,{}))
        for name,code,body in (('unclear_subject',400,raw),('aggregate_sum',503,raw),('aggregate_sum',400,b'{}')):
            self.assertFalse(review_case(name,code,body,label,{}))


if __name__=='__main__':unittest.main()
