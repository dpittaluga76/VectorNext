import argparse
import json
from pathlib import Path
from decimal import Decimal
from experiments.t32.summarize import mib
from evals.evidence.score import distribution
from .score import exact_load, score
from .run import ARMS, HERE, digest


def compact(audit):
    return {k:audit.get(k) for k in ('model','usage','input_tokens','elapsed_seconds','temperature',
                                    'planning_version','prompt_sha256','input_sha256','assessment')}


def summarize(root):
    root = Path(root)
    docs = exact_load((root/'corpus/documents.json').read_bytes())
    gold = exact_load((HERE/'gold.json').read_bytes())
    result = {'run':root.as_posix(), 'scheduled':24, 'arms':{},
              'execution_freeze_sha256':digest(root/'execution-freeze.json'),
              'source_archive_sha256':digest(root/'source.zip'),
              'corpus_sha256':digest(root/'corpus/documents.json'),
              'ingestion':json.loads((root/'corpus/ingestion.json').read_bytes())}
    for arm in ARMS:
        folder = root/arm; rows = []
        for identifier, label in gold.items():
            row = json.loads((folder/(identifier+'.row.json')).read_bytes())
            rawfile = folder/(identifier+'.response.json')
            if digest(rawfile) != row['response_sha256']: raise ValueError('response changed')
            row['score'] = score(row['http_status'], rawfile.read_bytes(), label, docs)
            audit = row['score'].pop('audit') or {}
            row['generation'] = compact(audit)
            row['generation']['assessment_audit'] = compact(audit.get('assessment_audit') or {})
            plan = row['score'].pop('planning') or {}
            row['planning'] = {'plan':plan.get('plan'), 'audit':compact(plan.get('audit') or {})}
            rows.append(row)
        samples = [json.loads(line) for line in (folder/'resources.jsonl').read_text().splitlines()]
        gpu = [float(s['gpu']['output'].strip().split(',')[2]) for s in samples
               if not s['gpu']['exit'] and s['gpu']['output'].strip()]
        memory = [json.loads(line) for s in samples if not s['containers']['exit']
                  for line in s['containers']['output'].splitlines() if line.strip()]
        resources = {service:{'peak_ram_mib':max((mib(r['MemUsage']) for r in memory
                        if r['Name'].endswith('-'+service+'-1')),default=None)} for service in ('api','processor','llm')}
        result['arms'][arm] = {'correct':sum(r['score']['correct'] for r in rows),
            'planning_correct':sum(r['score']['planning_correct'] for r in rows), 'total':8,
            'http_errors':sum(r['http_status'] not in (0,200) for r in rows),
            'expected_declines':sum(r['score']['correct'] and r['http_status']==400 for r in rows),
            'preflight_blocked':sum(r['seconds'] is None for r in rows),
            'latency_seconds':distribution([r['seconds'] for r in rows if r['seconds'] is not None]),
            'peak_device_memory_mib':max(gpu,default=None), 'resources':resources, 'cases':rows}
        for key in ('startup','restart'):
            file = folder/(key+'.json')
            result['arms'][arm][key+'_seconds'] = json.loads(file.read_bytes())['seconds'] if file.exists() else None
    for arm in result['arms'].values():
        arm['comparisons'] = {}
        for control in ARMS[:2]:
            pairs = list(zip(result['arms'][control]['cases'], arm['cases']))
            common = [(a,b) for a,b in pairs if a['score']['correct'] and b['score']['correct']]
            # Successful declines count as correct, but also publish positive-answer-only pairs.
            positive = [(a,b) for a,b in common if a['score'].get('status') == b['score'].get('status') == 'supported']
            arm['comparisons'][control] = {
                'gained':[b['case'] for a,b in pairs if b['score']['correct'] and not a['score']['correct']],
                'lost':[b['case'] for a,b in pairs if a['score']['correct'] and not b['score']['correct']],
                'common_correct_seconds':{'control':distribution([a['seconds'] for a,b in common]),
                                          'candidate':distribution([b['seconds'] for a,b in common])},
                'common_supported_seconds':{'control':distribution([a['seconds'] for a,b in positive]),
                                            'candidate':distribution([b['seconds'] for a,b in positive])}}
    before = json.loads((root/'normal-before.json').read_bytes())
    after = json.loads((root/'normal-after.json').read_bytes())
    result['normal_unchanged'] = all(before[k]==after[k] for k in ('documents','library','jobs'))
    result['normal_ready'] = after['ready']['ready']
    result['reporter_sha256'] = digest(Path(__file__))
    return result


def serializable(value):
    if isinstance(value, Decimal): return str(value)
    raise TypeError(type(value).__name__)


if __name__ == '__main__':
    p = argparse.ArgumentParser(); p.add_argument('--run',required=True); p.add_argument('--output',type=Path,required=True)
    a = p.parse_args()
    a.output.write_text(json.dumps(summarize(Path('data/t36')/a.run),indent=2,default=serializable)+'\n',encoding='utf-8',newline='\n')
