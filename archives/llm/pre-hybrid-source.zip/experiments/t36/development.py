"""Two known-regression planner probes, separate from the frozen fresh comparison."""
import argparse
import json
from pathlib import Path
from .run import Run, HERE, write, digest
from .score import match_fields


def execute(name):
    run = Run(name)
    before = run.normal_state(); write(run.root/'normal-before.json', before)
    if any(j['stage'] != 'Committed' for j in before['jobs']['jobs']):
        raise ValueError('normal ingestion is unfinished')
    original = json.loads(run.shell('docker', 'inspect', 'vectornext-llm-1'))[0]
    if not original['State']['Running']: raise ValueError('normal generator must be running')
    write(run.root/'normal-generator.json', original)
    run.freeze_execution(requests=2, arms=('nuextract3-requested-facts-v1',))
    cases = json.loads((HERE/'development-requests.json').read_bytes())
    rows = []
    try:
        run.shell('docker', 'stop', 'vectornext-llm-1')
        folder = run.root/'planner'; folder.mkdir()
        run.select('nuextract3-requested-facts-v1', 'development', folder)
        for case in cases:
            write(folder/(case['id']+'.attempt.json'), case['input'])
            # Only the public question/history enter inference. Gold remains in this process.
            script = """import json, urllib.request, urllib.error
value = INPUT
req = urllib.request.Request('http://127.0.0.1:8090/rpc/interactive',
    data=json.dumps({'op':'plan_fields','input':value}).encode(),
    headers={'Content-Type':'application/json'})
try:
    with urllib.request.urlopen(req, timeout=215) as response:
        print(json.dumps({'http_status':response.status,'raw':response.read().decode()}), flush=True)
except urllib.error.HTTPError as error:
    print(json.dumps({'http_status':error.code,'raw':error.read().decode()}), flush=True)
""".replace('INPUT', repr(case['input']))
            response = run.compose('exec', '-T', 'processor', 'python', '-c', script)
            (folder/(case['id']+'.response.json')).write_text(response, encoding='utf-8')
            captured = json.loads(response); envelope = json.loads(captured['raw'])
            body = envelope.get('result', envelope)
            # The RPC is a direct model-worker response, with no browser projection.
            passed = captured['http_status'] == 200 and match_fields(body.get('plan', {}), case['expected']) is not None
            rows.append({'case':case['id'], 'passed':passed, 'response_sha256':digest(folder/(case['id']+'.response.json'))})
            write(run.root/'results.json', rows)
            print(case['id'], passed, body.get('plan', body), flush=True)
        run.verify()
    finally:
        try:
            (run.root/'services.log').write_text(run.compose('logs', '--no-color'), encoding='utf-8')
            run.compose('down')
        finally:
            run.shell('docker', 'start', 'vectornext-llm-1'); run.wait_ready(normal=True)
            after = run.normal_state(); write(run.root/'normal-after.json', after)
            current = json.loads(run.shell('docker', 'inspect', 'vectornext-llm-1'))[0]
            if any(before[k] != after[k] for k in ('documents','library','jobs')) or current['Id'] != original['Id'] or current['Config'] != original['Config']:
                raise ValueError('normal app changed')
    if len(rows) != 2 or not all(r['passed'] for r in rows):
        raise ValueError('known planning repair is not verified; fresh comparison must not start')


if __name__ == '__main__':
    p = argparse.ArgumentParser(); p.add_argument('--run', required=True)
    execute(p.parse_args().run)
