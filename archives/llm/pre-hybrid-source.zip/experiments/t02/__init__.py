"""Local model feasibility checks."""
