import argparse
import json
from pathlib import Path
from experiments.t32.score import exact_load, score as explicit_score
from experiments.t32.summarize import mib
from evals.evidence.score import distribution
from .run import ARMS, HERE, SELECTED, write, digest


from experiments.t34.report import case_score, pdf_exception


def summarize(root):
    root=Path(root);docs=exact_load((root/'corpus/documents.json').read_bytes())
    all_gold=exact_load(Path('experiments/t32/gold.json').read_bytes())
    gold={key:all_gold[key] for key in SELECTED}
    browser=exact_load((HERE/'browser-gold.json').read_bytes())
    result={'run':root.as_posix(),'scheduled':24,'arms':{},'execution_freeze_sha256':digest(root/'execution-freeze.json'),
            'source_archive_sha256':digest(root/'source.zip'),'corpus_sha256':digest(root/'corpus/documents.json'),
            'ingestion':json.loads((root/'corpus/ingestion.json').read_bytes()),
            'review_reference':'docs/reports/t32-source-review.md'}
    for arm in ARMS:
        folder=root/arm;rows=[]
        for identifier,label in {**gold,**browser}.items():
            row=json.loads((folder/(identifier+'.row.json')).read_bytes())
            raw=(folder/(identifier+'.response.json')).read_bytes()
            if digest(folder/(identifier+'.response.json'))!=row['response_sha256']:raise ValueError('response changed')
            row['score']=case_score(row['http_status'],raw,label,docs,identifier in browser)
            # Reports keep audit JSON in its original raw capture to avoid Decimal
            # coercion or bloating a summary; keep useful stable diagnostics here.
            audit=row['score'].pop('audit') or {}
            row['generation']={k:audit.get(k) for k in ('model','usage','input_tokens','elapsed_seconds','temperature','assessment')}
            row['generation']['assessment_audit']={k:(audit.get('assessment_audit') or {}).get(k)
                for k in ('model','usage','input_tokens','elapsed_seconds','temperature')}
            plan=row['score'].pop('planning') or {}
            row['planning']={'plan':plan.get('plan'),'audit':{k:plan.get('audit',{}).get(k)
                for k in ('model','usage','input_tokens','elapsed_seconds','temperature')}}
            row['reviewed_correct']=row['score']['correct'] or (identifier=='pdf_correction' and pdf_exception(row['http_status'],raw,docs))
            rows.append(row)
        samples=[json.loads(line) for line in (folder/'resources.jsonl').read_text().splitlines()]
        gpu=[float(s['gpu']['output'].strip().split(',')[2]) for s in samples if not s['gpu']['exit'] and s['gpu']['output'].strip()]
        resources={}
        for service in ('api','processor','llm'):
            memory=[json.loads(line) for s in samples if not s['containers']['exit']
                    for line in s['containers']['output'].splitlines() if line.strip()]
            memory=[r for r in memory if r['Name'].endswith('-'+service+'-1')]
            resources[service]={'peak_ram_mib':max((mib(r['MemUsage']) for r in memory),default=None),'samples':len(memory)}
        result['arms'][arm]={'correct':sum(r['score']['correct'] for r in rows),
            'reviewed_correct':sum(r['reviewed_correct'] for r in rows),'total':6,
            'http_errors':sum(r['http_status'] not in (0,200) for r in rows),
            'preflight_blocked':sum(r['seconds'] is None for r in rows),
            'latency_seconds':distribution([r['seconds'] for r in rows if r['seconds'] is not None]),
            'peak_device_memory_mib':max(gpu,default=None),'resources':resources,'cases':rows}
        for key in ('startup','restart'):
            file=folder/(key+'.json')
            result['arms'][arm][key+'_seconds']=json.loads(file.read_bytes())['seconds'] if file.exists() else None
    baseline=result['arms']['12b-temp1']['cases']
    for arm in result['arms'].values():
        pairs=list(zip(baseline,arm['cases']))
        arm['gained']=[b['case'] for a,b in pairs if b['reviewed_correct'] and not a['reviewed_correct']]
        arm['lost']=[b['case'] for a,b in pairs if a['reviewed_correct'] and not b['reviewed_correct']]
        common=[(a,b) for a,b in pairs if a['reviewed_correct'] and b['reviewed_correct']]
        arm['common_success_seconds']={'baseline':distribution([a['seconds'] for a,b in common]),
                                      'candidate':distribution([b['seconds'] for a,b in common])}
    before=json.loads((root/'normal-before.json').read_bytes());after=json.loads((root/'normal-after.json').read_bytes())
    result['normal_unchanged']=all(before[k]==after[k] for k in ('documents','library','jobs'))
    result['normal_ready']=after['ready']['ready']
    result['reporter_sha256']=digest(Path(__file__))
    return result


def serializable(value):
    from decimal import Decimal
    if isinstance(value,Decimal):return str(value)
    raise TypeError(type(value).__name__)


if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--run',required=True);p.add_argument('--output',type=Path,required=True)
    a=p.parse_args();a.output.write_text(json.dumps(summarize(Path('data/t35')/a.run),indent=2,default=serializable)+'\n',encoding='utf-8',newline='\n')
