import copy
import json
import unittest
from types import SimpleNamespace
from model_worker import generator_profile as profiles, answers
from model_worker.extraction_template import options, project
from model_worker.scheduler import validate, Rejected
from .run import ARMS, validate as validate_inputs


class TemperatureProfiles(unittest.TestCase):
    def test_exact_temperatures_and_unchanged_legacy_profiles(self):
        expected = dict(zip(ARMS, (1.0, 0.7, 1.0, 0.2)))
        for name, value in expected.items():
            profile = profiles.load(name)
            self.assertEqual(profiles.answer_temperature(profile), value)
            self.assertIn('answer-temperature=' + str(value), profiles.runtime_identity(profile))
            self.assertEqual(profiles.validate_command(profile, profiles.command(profile)), profiles.command(profile))
        for name in ('12b', 'qwen35-9b-q4km', 'granite42-8b-q4km'):
            profile = profiles.load(name)
            self.assertEqual(profiles.answer_temperature(profile), 0)
            self.assertNotIn('answer-temperature', profiles.runtime_identity(profile))
        self.assertEqual(json.loads(profiles.CATALOG.read_bytes())['default'], '12b')

    def test_temperature_rejects_invalid_values(self):
        for value in (True, '1', float('nan'), float('inf'), -0.1, 2.1):
            with self.assertRaises(ValueError):
                profiles.answer_temperature({'answer_temperature': value})

    def test_scheduler_binds_temperature_alias_and_priority(self):
        for name in ARMS:
            profile = profiles.load(name)
            temp = profiles.answer_temperature(profile)
            request = {'model': profile['alias'], 'temperature': temp, 'max_tokens': 768}
            args = (profile['alias'], temp, profiles.answer_adapter(profile))
            validate('/v1/chat/completions', json.dumps(request), 'interactive', *args)
            for mutation in ({'temperature': 0}, {'temperature': True}, {'model': 'wrong'}):
                with self.assertRaises(Rejected):
                    validate('/v1/chat/completions', json.dumps({**request, **mutation}), 'interactive', *args)
            with self.assertRaises(Rejected):
                validate('/v1/chat/completions', json.dumps(request), 'background', *args)
            validate('/v1/chat/completions', json.dumps({**request, 'temperature': 0, 'max_tokens': 256}), 'background', *args)

    def test_adapter_options_only_for_selected_profile(self):
        profile = profiles.load('nuextract3-q4km')
        adapted = options(profile, answers.ASSESS_SCHEMA)
        payload = {'messages': [], **adapted}
        validate('/apply-template', json.dumps(payload), 'interactive', profile['alias'], 0.2, 'nuextract3-v1')
        with self.assertRaises(Rejected):
            validate('/apply-template', json.dumps(payload), 'interactive')
        for mutation in ({'enable_thinking': True}, {'untrusted_flag': 'yes'}, {'template': '[]'}):
            bad = {**adapted['chat_template_kwargs'], **mutation}
            with self.assertRaises((Rejected, ValueError)):
                validate('/apply-template', json.dumps({'chat_template_kwargs': bad}), 'interactive', profile['alias'], 0.2, 'nuextract3-v1')

    def test_schema_projection_keeps_union_guidance_and_never_changes_schema(self):
        fields = {'count': {'kind': 'integer', 'nullable': False, 'pointer': None}}
        evidence = [{'id': 'E1', 'record': {}, 'text': '{"a/b":9007199254740993,"unknown":null}'},
                    {'id': 'E2', 'record': None, 'text': 'The count is 12.'}]
        schema = answers.schema(fields, evidence, True)
        original = copy.deepcopy(schema)
        projected = project([schema])
        self.assertEqual(schema, original)
        self.assertEqual(projected['status'], ['supported', 'ambiguous', 'insufficient_evidence'])
        self.assertEqual(projected['fields']['count']['value'], 'integer')
        self.assertEqual(projected['fields']['count']['pointer'], ['/a~1b', '/unknown'])
        self.assertEqual(projected['fields']['count']['quote'], 'verbatim-string')
        with self.assertRaises(ValueError):
            project([{'type': 'string'}, {'type': 'integer'}])

    def test_count_and_generation_use_same_template_and_temperature_with_original_grammar(self):
        calls = []
        def http(path, payload, **kwargs):
            calls.append((path, payload))
            if path == '/apply-template': return {'prompt': 'rendered including native template'}
            if path == '/tokenize': return {'tokens': [1, 2, 3]}
            return {'choices': [{'finish_reason': 'stop', 'message': {'content': '{"status":"insufficient_evidence","reason":"missing"}'}}]}
        profile = profiles.load('nuextract3-q4km')
        worker = SimpleNamespace(generation_profile=profile, generator_alias=profile['alias'], calls={}, http=http,
                                 generator={k: k for k in ('model', 'revision', 'artifact_sha256', 'runtime')})
        _, audit = answers.generate(worker, [{'role':'user','content':'fixture'}], answers.ASSESS_SCHEMA, 'instruction')
        self.assertEqual(calls[0][1]['chat_template_kwargs'], calls[2][1]['chat_template_kwargs'])
        self.assertEqual(calls[2][1]['temperature'], 0.2)
        self.assertEqual(calls[2][1]['response_format']['json_schema']['schema'], answers.ASSESS_SCHEMA)
        self.assertEqual(audit['temperature'], 0.2)
        self.assertEqual(audit['input_tokens'], 3)
        self.assertEqual(audit['template_adapter'], 'nuextract3-v1')

    def test_frozen_twenty_four_request_selection(self):
        self.assertEqual(len(validate_inputs()) * len(ARMS), 24)


if __name__ == '__main__': unittest.main()
