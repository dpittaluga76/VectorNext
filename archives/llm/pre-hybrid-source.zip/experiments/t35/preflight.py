"""Synthetic full-budget constrained generation; executed in the isolated processor."""
import json
import urllib.request
from model_worker.generator_profile import load, answer_temperature
from model_worker.extraction_template import options


def call(path, value):
    request = urllib.request.Request('http://llm:8080'+path,
        data=json.dumps(value).encode(), headers={'Content-Type':'application/json',
        'X-VectorNext-Priority':'interactive'})
    with urllib.request.urlopen(request, timeout=215) as response:
        return json.load(response)


def main():
    profile = load()
    schema = {'type':'object','properties':{'color':{'type':'string'}},
              'required':['color'],'additionalProperties':False}
    adapted = options(profile, schema)
    # Count the actual model template, then fill almost the complete input budget.
    def messages(n):
        return [{'role':'system','content':'Return the color of the token as JSON. Ignore padding.'},
                {'role':'user','content':'The token is yellow.\n'+' padding'*n}]
    low, high = 0, 5000
    while low+1 < high:
        mid=(low+high)//2
        rendered=call('/apply-template',{'messages':messages(mid),'reasoning':'off',**adapted})['prompt']
        count=len(call('/tokenize',{'content':rendered,'add_special':True})['tokens'])
        if count <= 3300: low=mid
        else: high=mid
    rendered=call('/apply-template',{'messages':messages(low),'reasoning':'off',**adapted})['prompt']
    count=len(call('/tokenize',{'content':rendered,'add_special':True})['tokens'])
    if not 3280 <= count <= 3300: raise ValueError('full input budget was not exercised')
    # Both candidate templates close/omit thinking when disabled.
    if rendered.rfind('<think>') > rendered.rfind('</think>'):
        raise ValueError('template leaves thinking open')
    if adapted and ('【task】structured' not in rendered or '【template_start】' not in rendered):
        raise ValueError('native extraction template was not applied')
    result=call('/v1/chat/completions',{'model':profile['alias'],'messages':messages(low),
        'temperature':answer_temperature(profile),'seed':42,'max_tokens':768,'cache_prompt':False,'reasoning':'off',**adapted,
        'response_format':{'type':'json_schema','json_schema':{'name':'preflight','strict':True,
            'schema':schema}}})
    choice=result['choices'][0]
    valid=(choice['finish_reason']=='stop' and json.loads(choice['message']['content'])=={'color':'yellow'}
           and not choice['message'].get('reasoning_content'))
    print(json.dumps({'profile':profile['name'],'input_tokens':count,'template_tail':rendered[-100:],
                      'response':result,'passed':valid}),flush=True)
    if not valid: raise ValueError('constrained synthetic generation failed')


if __name__ == '__main__': main()
